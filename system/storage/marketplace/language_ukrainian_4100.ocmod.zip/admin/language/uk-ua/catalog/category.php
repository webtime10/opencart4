<?php
// Heading
$_['heading_title']          = 'Категорії';

// Text
$_['text_success']           = 'Налаштування змінені';
$_['text_list']              = 'Список категорій';
$_['text_add']               = 'Додати';
$_['text_edit']              = 'Редагування';
$_['text_filter']            = 'Фільтр';
$_['text_default']           = 'За замовчуванням';
$_['text_keyword']           = 'Має бути унікальним на всю систему, без пробілів та спецсимволів';

// Column
$_['column_name']            = 'Назва категорії';
$_['column_sort_order']      = 'Порядок сортування';
$_['column_action']          = 'Дія';

// Entry
$_['entry_name']             = 'Назва категорії';
$_['entry_description']      = 'Опис';
$_['entry_meta_title']       = 'Мета-тег Title';
$_['entry_meta_keyword']     = 'Мета-тег Keywords';
$_['entry_meta_description'] = 'Мета-тег Description';
$_['entry_store']            = 'Магазини';
$_['entry_keyword']          = 'SEO URL';
$_['entry_parent']           = 'Головна категорія';
$_['entry_filter']           = 'Фільтри';
$_['entry_image']            = 'Зображення';
$_['entry_sort_order']       = 'Порядок сортування';
$_['entry_status']           = 'Статус';
$_['entry_layout']           = 'Змінити макет';

// Help
$_['help_parent']            = '(Автодоповнення)';
$_['help_filter']            = '(Автодоповнення)';

// Error
$_['error_warning']          = 'Будь ласка, перевірте форму на наявність помилок';
$_['error_permission']       = 'У вас недостатньо прав для внесення змін';
$_['error_name']             = 'Назва має містити від 1 до 255 символів';
$_['error_meta_title']       = 'Мета-тег Title має містити від 1 до 255 символів';
$_['error_parent']           = 'Вибрана вами батьківська категорія є дочірньою для поточної';
$_['error_keyword']          = 'Будь ласка, вкажіть SEO URL від 1 до 64 символів';
$_['error_keyword_exists']   = 'SEO URL має бути унікальним';
$_['error_keyword_character'] = 'SEO URL може містити тільки символи a-z, 0-9, - та _';
