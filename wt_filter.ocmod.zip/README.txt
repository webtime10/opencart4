WT Filter for OpenCart 4.x
==========================

Install
-------
1. Admin → Extensions → Installer → upload wt_filter.ocmod.zip
2. Click Install (green +) for "WT Filter"
3. Admin → Extensions → Extensions → Modules → Install "WT Filter", then Edit / Save
4. Admin → Extensions → Modifications → find "WT Filter" → Enable if needed → Refresh (blue button)
5. Dashboard gear → clear cache
6. Re-login (so new permissions apply)

Result
------
- Catalog → WT Filter (empty page stub)
- Extensions → Modules → WT Filter (copy filters settings)
- Product form hooks prepared (tab JS/CSS later)

Notes
-----
- Menu is added by Event on module install (not OCMOD).
- Do not use old OC3-style root install.xml zip on OC4.
- Package layout:
    install.json
    admin/...
    ocmod/wt_filter.ocmod.xml
