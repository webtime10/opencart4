<?php
$_['heading_title'] = 'WT Filter';
$_['text_home']     = 'Home';
$_['text_empty']    = 'Filter options list will be here.';
