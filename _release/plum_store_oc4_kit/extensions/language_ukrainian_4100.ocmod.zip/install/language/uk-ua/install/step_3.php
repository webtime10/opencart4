<?php
// Heading
$_['heading_title']          = 'Конфігурація';

// Text
$_['text_step_3']            = 'Введіть інформацію про свою базу даних та адміністратора';
$_['text_db_connection']     = '1. Введіть дані підключення до бази даних';
$_['text_db_advanced']       = 'Додаткові параметри БД';
$_['text_db_administration'] = '2. Будь ласка, введіть ім’я користувача та пароль для адміністратора';
$_['text_mysqli']            = 'MySQLi';
$_['text_pdo']               = 'mPDO';
$_['text_help']              = 'Інформація про налаштування баз даних на різних платформах:';
$_['text_cpanel']            = 'Налаштування БД у CPanel';
$_['text_plesk']             = 'Налаштування БД у Plesk';
$_['text_db_ssl']            = 'Вхідні дані сертифіката повинні бути додані як один рядок, наприклад: "MIIDrzCCApegAwIBAgIQ....=="';

// Entry
$_['entry_db_driver']        = 'Драйвер';
$_['entry_db_hostname']      = 'Хост';
$_['entry_db_username']      = 'Користувач';
$_['entry_db_password']      = 'Пароль';
$_['entry_db_database']      = 'Ім’я БД';
$_['entry_db_port']          = 'Порт';
$_['entry_db_prefix']        = 'Префікс';
$_['entry_db_advanced']      = 'Додатково';
$_['entry_db_ssl_key']       = 'SSL Key';
$_['entry_db_ssl_cert']      = 'SSL Cert';
$_['entry_db_ssl_ca']        = 'SSL CA';
$_['entry_username']         = 'Логін';
$_['entry_password']         = 'Пароль';
$_['entry_email']            = 'E-Mail';

// Error
$_['error_db_driver']        = 'Вкажіть драйвер бази даних!';
$_['error_db_hostname']      = 'Вкажіть хост бази даних';
$_['error_db_username']      = 'Вкажіть ім’я користувача бази даних';
$_['error_db_database']      = 'Вкажіть ім’я бази даних';
$_['error_db_port']          = 'Вкажіть порт бази даних';
$_['error_db_prefix']        = 'Префікс бази даних може містити лише символи нижнього регістру в діапазоні a–z, 0–9 та підкреслення';
$_['error_db_connect']       = 'Не вдалося підключитися до бази даних, переконайтеся, що сервер бази даних, ім’я користувача та пароль правильні';
$_['error_username']         = 'Вкажіть логін адміністратора';
$_['error_password']         = 'Вкажіть пароль адміністратора';
$_['error_email']            = 'Невірно вказано адресу електронної пошти';
$_['error_config']           = 'Не вдалося записати в config.php, будь ласка, перевірте, чи встановлено правильні дозволи: ';
