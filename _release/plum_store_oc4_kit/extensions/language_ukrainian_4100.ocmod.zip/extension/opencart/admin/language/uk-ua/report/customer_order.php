<?php
// Heading
$_['heading_title']         = 'Звіт по замовленням покупців';

// Text
$_['text_extension']        = 'Доповнення';
$_['text_edit']             = 'Редагування';
$_['text_success']          = 'Налаштування змінені';
$_['text_filter']           = 'Фільтр';
$_['text_all_status']       = 'Всі статуси';

// Column
$_['column_customer']       = 'Ім’я покупця';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Група покупців';
$_['column_status']         = 'Статус';
$_['column_orders']         = 'Кількість замовлень';
$_['column_products']       = 'Кількість товарів';
$_['column_total']          = 'Разом';
$_['column_action']         = 'Дія';

// Entry
$_['entry_date_start']      = 'Початкова дата';
$_['entry_date_end']        = 'Кінцева дата';
$_['entry_customer']        = 'Покупець';
$_['entry_order_status']    = 'Статус замовлення';
$_['entry_status']          = 'Статус';
$_['entry_sort_order']      = 'Сортування';

// Error
$_['error_permission']      = 'У вас недостатньо прав для внесення змін';
