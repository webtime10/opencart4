<?php
$_['heading_title'] = 'WT Filter';
$_['text_home']     = 'Головна';
$_['text_empty']    = 'Тут буде список опцій фільтра.';
