/**
 * WT Filter — product form tab (stub).
 * Full UI will be added later (callback + options).
 */
(function ($) {
	'use strict';

	window.wt_filter = window.wt_filter || {};

	// Placeholder: product form JS will create #tab-wt_filter here.
})(jQuery);
