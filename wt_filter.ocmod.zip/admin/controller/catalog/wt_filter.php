<?php
namespace Opencart\Admin\Controller\Extension\WtFilter\Catalog;

/**
 * Заглушка страницы Каталог → WT Filter (как в OC3).
 * Позже здесь будет список опций фильтра.
 */
class WtFilter extends \Opencart\System\Engine\Controller {
	private string $route = 'extension/wt_filter/catalog/wt_filter';

	public function index(): void {
		$this->load->language($this->route);

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'])
		];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view($this->route, $data));
	}
}
