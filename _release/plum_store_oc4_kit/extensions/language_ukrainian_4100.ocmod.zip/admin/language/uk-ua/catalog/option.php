<?php
// Heading
$_['heading_title']       = 'Опції';

// Text
$_['text_success']        = 'Налаштування змінені';
$_['text_list']           = 'Список опцій';
$_['text_add']            = 'Додати';
$_['text_edit']           = 'Редагування';
$_['text_choose']         = 'Вибір';
$_['text_select']         = 'Список';
$_['text_radio']          = 'Перемикач';
$_['text_checkbox']       = 'Прапорець';
$_['text_input']         = 'Поле вводу';
$_['text_text']          = 'Текст';
$_['text_textarea']      = 'Текстова область';
$_['text_file']          = 'Файл';
$_['text_date']          = 'Дата';
$_['text_datetime']      = 'Дата та час';
$_['text_time']          = 'Час';
$_['text_option']        = 'Опція';
$_['text_value']         = 'Значення';

// Column
$_['column_name']        = 'Назва опції';
$_['column_sort_order']  = 'Порядок сортування';
$_['column_action']      = 'Дія';

// Entry
$_['entry_name']         = 'Назва опції';
$_['entry_type']         = 'Тип';
$_['entry_option_value'] = 'Назва значення опції';
$_['entry_image']        = 'Зображення';
$_['entry_sort_order']   = 'Порядок сортування';

// Error
$_['error_warning']      = 'Будь ласка, перевірте форму на наявність помилок';
$_['error_permission']   = 'У вас недостатньо прав для внесення змін';
$_['error_name']         = 'Назва має містити від 1 до 128 символів';
$_['error_type']         = 'Вкажіть значення';
$_['error_option_value'] = 'Значення має містити від 1 до 128';
$_['error_value']        = 'Значення опції неможливо видалити тому, що воно використовується в %s товарах';
$_['error_product']      = 'Опцію неможливо видалити тому, що вона використовується в %s товарах';
