<?php
// Heading
$_['heading_title']    = 'Боротьба з шахрайством';

// Text
$_['text_success']     = 'Налаштування змінені';
$_['text_list']        = 'Список доповнень';

// Column
$_['column_name']      = 'Назва';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Дія';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін';
$_['error_extension']  = 'Доповнення не знайдено';