<?php
namespace Opencart\Admin\Model\Extension\WtFilter\Catalog;

/**
 * Модель wt_filter — install таблиц + copyFilters по шагам.
 */
class WtFilter extends \Opencart\System\Engine\Model {
	public function install(): void {
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wt_filter_option` (
				`option_id` int(11) NOT NULL AUTO_INCREMENT,
				`type` varchar(32) NOT NULL DEFAULT 'checkbox',
				`keyword` varchar(255) NOT NULL DEFAULT '',
				`status` tinyint(1) NOT NULL DEFAULT '0',
				`sort_order` int(11) NOT NULL DEFAULT '0',
				`grouping` int(11) NOT NULL DEFAULT '0',
				`selectbox` tinyint(1) NOT NULL DEFAULT '0',
				`color` tinyint(1) NOT NULL DEFAULT '0',
				`image` tinyint(1) NOT NULL DEFAULT '0',
				PRIMARY KEY (`option_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wt_filter_option_description` (
				`option_id` int(11) NOT NULL,
				`language_id` int(11) NOT NULL,
				`name` varchar(255) NOT NULL DEFAULT '',
				`description` text NOT NULL,
				`postfix` varchar(32) NOT NULL DEFAULT '',
				PRIMARY KEY (`option_id`,`language_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wt_filter_option_to_category` (
				`option_id` int(11) NOT NULL,
				`category_id` int(11) NOT NULL,
				PRIMARY KEY (`option_id`,`category_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wt_filter_option_to_store` (
				`option_id` int(11) NOT NULL,
				`store_id` int(11) NOT NULL,
				PRIMARY KEY (`option_id`,`store_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wt_filter_option_value` (
				`value_id` bigint(20) NOT NULL AUTO_INCREMENT,
				`option_id` int(11) NOT NULL,
				`keyword` varchar(255) NOT NULL DEFAULT '',
				`color` varchar(7) NOT NULL DEFAULT '',
				`image` varchar(255) NOT NULL DEFAULT '',
				`sort_order` int(11) NOT NULL DEFAULT '0',
				PRIMARY KEY (`value_id`),
				KEY `option_id` (`option_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wt_filter_option_value_description` (
				`value_id` bigint(20) NOT NULL,
				`option_id` int(11) NOT NULL,
				`language_id` int(11) NOT NULL,
				`name` varchar(255) NOT NULL DEFAULT '',
				PRIMARY KEY (`value_id`,`language_id`),
				KEY `option_id` (`option_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wt_filter_option_value_to_product` (
				`product_id` int(11) NOT NULL,
				`option_id` int(11) NOT NULL,
				`value_id` bigint(20) NOT NULL,
				`slide_value_min` decimal(15,4) NOT NULL DEFAULT '0.0000',
				`slide_value_max` decimal(15,4) NOT NULL DEFAULT '0.0000',
				PRIMARY KEY (`product_id`,`option_id`,`value_id`),
				KEY `option_id` (`option_id`),
				KEY `value_id` (`value_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
		");
	}

	public function uninstall(): void {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "wt_filter_option`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "wt_filter_option_description`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "wt_filter_option_to_category`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "wt_filter_option_to_store`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "wt_filter_option_value`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "wt_filter_option_value_description`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "wt_filter_option_value_to_product`");
	}

	/**
	 * step: truncate | option | filter | attribute | finalize
	 */
	public function copyFiltersStep(string $step, array $data = []): void {
		$copy_type = !empty($data['copy_type']) ? $data['copy_type'] : 'checkbox';

		switch ($step) {
			case 'truncate':
				$this->db->query("TRUNCATE `" . DB_PREFIX . "wt_filter_option`");
				$this->db->query("TRUNCATE `" . DB_PREFIX . "wt_filter_option_description`");
				$this->db->query("TRUNCATE `" . DB_PREFIX . "wt_filter_option_to_category`");
				$this->db->query("TRUNCATE `" . DB_PREFIX . "wt_filter_option_to_store`");
				$this->db->query("TRUNCATE `" . DB_PREFIX . "wt_filter_option_value`");
				$this->db->query("TRUNCATE `" . DB_PREFIX . "wt_filter_option_value_to_product`");
				$this->db->query("TRUNCATE `" . DB_PREFIX . "wt_filter_option_value_description`");
				break;

			case 'option':
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option` (option_id, `type`, `status`, sort_order, image) SELECT option_id, '" . $this->db->escape($copy_type) . "', '1', sort_order, IF(`type` = 'image', 1, 0) FROM `" . DB_PREFIX . "option`");
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_description` (option_id, language_id, name) SELECT option_id, language_id, name FROM `" . DB_PREFIX . "option_description`");
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value` (value_id, option_id, image, sort_order) SELECT option_value_id, option_id, image, sort_order FROM `" . DB_PREFIX . "option_value`");
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value_description` (value_id, option_id, language_id, name) SELECT option_value_id, option_id, language_id, name FROM `" . DB_PREFIX . "option_value_description`");
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value_to_product` (product_id, value_id, option_id) SELECT product_id, option_value_id, option_id FROM `" . DB_PREFIX . "product_option_value` WHERE quantity > '0'");
				break;

			case 'filter':
				$last_option_id = 10000;
				$last_value_id = 10000;

				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option` (option_id, `type`, `status`, sort_order) SELECT (filter_group_id + '" . (int)$last_option_id . "'), '" . $this->db->escape($copy_type) . "', '1', sort_order FROM `" . DB_PREFIX . "filter_group`");
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_description` (option_id, language_id, name) SELECT (filter_group_id + '" . (int)$last_option_id . "'), language_id, name FROM `" . DB_PREFIX . "filter_group_description`");
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value` (value_id, option_id, sort_order) SELECT (filter_id + '" . (int)$last_value_id . "'), (filter_group_id + '" . (int)$last_option_id . "'), sort_order FROM `" . DB_PREFIX . "filter`");
				// OC4: filter_group_id is only in `filter`, not in `filter_description`
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value_description` (value_id, option_id, language_id, name) SELECT (fd.filter_id + '" . (int)$last_value_id . "'), (f.filter_group_id + '" . (int)$last_option_id . "'), fd.language_id, fd.name FROM `" . DB_PREFIX . "filter_description` fd LEFT JOIN `" . DB_PREFIX . "filter` f ON (f.filter_id = fd.filter_id)");
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value_to_product` (product_id, value_id, option_id) SELECT pf.product_id, (pf.filter_id + '" . (int)$last_value_id . "'), (SELECT oov.option_id FROM `" . DB_PREFIX . "wt_filter_option_value` oov WHERE oov.value_id = (pf.filter_id + '" . (int)$last_value_id . "')) AS option_id FROM `" . DB_PREFIX . "product_filter` pf");
				break;

			case 'attribute':
				$this->copyAttributes($data, $copy_type);
				break;

			case 'finalize':
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_to_category` (option_id, category_id) SELECT oov2p.option_id, p2c.category_id FROM `" . DB_PREFIX . "wt_filter_option_value_to_product` oov2p LEFT JOIN `" . DB_PREFIX . "product_to_category` p2c ON (p2c.product_id = oov2p.product_id) WHERE p2c.category_id != '0' GROUP BY oov2p.option_id, p2c.category_id");

				if (!empty($data['copy_store']) && is_array($data['copy_store'])) {
					foreach ($data['copy_store'] as $store_id) {
						$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_to_store` (option_id, store_id) SELECT option_id, '" . (int)$store_id . "' AS store_id FROM `" . DB_PREFIX . "wt_filter_option`");
					}
				}

				$query = $this->db->query("SELECT oo.option_id, ood.name FROM `" . DB_PREFIX . "wt_filter_option` oo LEFT JOIN `" . DB_PREFIX . "wt_filter_option_description` ood ON (oo.option_id = ood.option_id) WHERE ood.language_id = '" . (int)$this->config->get('config_language_id') . "' AND oo.`keyword` = ''");

				foreach ($query->rows as $row) {
					$this->db->query("UPDATE `" . DB_PREFIX . "wt_filter_option` SET `keyword` = '" . $this->db->escape($this->translit($row['name'])) . "' WHERE option_id = '" . (int)$row['option_id'] . "'");
				}

				$query = $this->db->query("SELECT oov.value_id, oovd.name FROM `" . DB_PREFIX . "wt_filter_option_value` oov LEFT JOIN `" . DB_PREFIX . "wt_filter_option_value_description` oovd ON (oov.value_id = oovd.value_id) WHERE oovd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND oov.`keyword` = ''");

				foreach ($query->rows as $row) {
					$this->db->query("UPDATE `" . DB_PREFIX . "wt_filter_option_value` SET `keyword` = '" . $this->db->escape($this->translit($row['name'])) . "' WHERE value_id = '" . $this->db->escape($row['value_id']) . "'");
				}

				$this->cache->delete('wt_filter');
				$this->cache->delete('product');
				break;
		}
	}

	private function copyAttributes(array $data, string $copy_type): void {
		$this->db->query("UPDATE `" . DB_PREFIX . "product_attribute` SET text = TRIM(text)");

		$last_option_id = 30000;

		$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option` (option_id, status, type, sort_order) SELECT (attribute_id + '" . (int)$last_option_id . "'), '1' AS status, '" . $this->db->escape($copy_type) . "' AS type, sort_order FROM `" . DB_PREFIX . "attribute`");
		$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_description` (option_id, language_id, name) SELECT (attribute_id + '" . (int)$last_option_id . "'), language_id, name FROM `" . DB_PREFIX . "attribute_description`");

		$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value` (option_id, value_id) SELECT (attribute_id + '" . (int)$last_option_id . "'), CRC32(CONCAT(attribute_id, CONCAT(UCASE(LEFT(TRIM(text), 1)), LCASE(SUBSTRING(TRIM(text), 2))))) FROM `" . DB_PREFIX . "product_attribute` WHERE language_id = '" . (int)$this->config->get('config_language_id') . "' GROUP BY attribute_id, CONCAT(UCASE(LEFT(TRIM(text), 1)), LCASE(SUBSTRING(TRIM(text), 2)))");
		$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value_description` (option_id, value_id, language_id, name) SELECT (attribute_id + '" . (int)$last_option_id . "'), CRC32(CONCAT(attribute_id, CONCAT(UCASE(LEFT(TRIM(text), 1)), LCASE(SUBSTRING(TRIM(text), 2))))), language_id, TRIM(text) FROM `" . DB_PREFIX . "product_attribute` WHERE language_id = '" . (int)$this->config->get('config_language_id') . "' GROUP BY attribute_id, CONCAT(UCASE(LEFT(TRIM(text), 1)), LCASE(SUBSTRING(TRIM(text), 2)))");

		$this->load->model('localisation/language');
		$languages = $this->model_localisation_language->getLanguages();

		foreach ($languages as $language) {
			if ((int)$language['language_id'] !== (int)$this->config->get('config_language_id')) {
				$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value_description` (option_id, value_id, language_id, name)
					SELECT
						(pa.attribute_id + '" . (int)$last_option_id . "'),
						(SELECT CRC32(CONCAT(pa2.attribute_id, CONCAT(UCASE(LEFT(TRIM(pa2.text), 1)), LCASE(SUBSTRING(TRIM(pa2.text), 2))))) FROM `" . DB_PREFIX . "product_attribute` pa2
							WHERE pa2.language_id = '" . (int)$this->config->get('config_language_id') . "'
							AND pa2.product_id = pa.product_id
							AND pa2.attribute_id = pa.attribute_id LIMIT 1
						) AS value_id, '" . (int)$language['language_id'] . "', CONCAT(UCASE(LEFT(TRIM(pa.text), 1)), LCASE(SUBSTRING(TRIM(pa.text), 2)))
					FROM `" . DB_PREFIX . "product_attribute` pa WHERE pa.language_id = '" . (int)$language['language_id'] . "' GROUP BY pa.attribute_id, CONCAT(UCASE(LEFT(TRIM(pa.text), 1)), LCASE(SUBSTRING(TRIM(pa.text), 2)))");
			}
		}

		$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "wt_filter_option_value_to_product` (product_id, option_id, value_id) SELECT product_id, (attribute_id + '" . (int)$last_option_id . "'), CRC32(CONCAT(attribute_id, CONCAT(UCASE(LEFT(TRIM(text), 1)), LCASE(SUBSTRING(TRIM(text), 2))))) AS value_id FROM `" . DB_PREFIX . "product_attribute` WHERE language_id = '" . (int)$this->config->get('config_language_id') . "'");

		$separator = '';
		if (!empty($data['module_wt_filter_attribute_separator'])) {
			$separator = (string)$data['module_wt_filter_attribute_separator'];
		}

		if ($separator === '') {
			return;
		}

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "wt_filter_option_value_description` WHERE language_id = '" . (int)$this->config->get('config_language_id') . "' AND TRIM(name) LIKE '%" . $this->db->escape($separator) . "%'");

		foreach ($query->rows as $result) {
			$values = explode($separator, $result['name']);

			foreach ($values as $value) {
				$value = $this->ucfirstUtf8(trim($value));

				if (!$value) {
					continue;
				}

				$value_query = $this->db->query("SELECT value_id FROM `" . DB_PREFIX . "wt_filter_option_value_description` WHERE language_id = '" . (int)$this->config->get('config_language_id') . "' AND option_id = '" . (int)$result['option_id'] . "' AND LCASE(TRIM(name)) = '" . $this->db->escape(oc_strtolower($value)) . "'");

				if ($value_query->num_rows) {
					$value_id = $value_query->row['value_id'];
				} else {
					$this->db->query("INSERT INTO `" . DB_PREFIX . "wt_filter_option_value` (option_id) VALUES ('" . (int)$result['option_id'] . "')");
					$value_id = $this->db->getLastId();
					$this->db->query("INSERT INTO `" . DB_PREFIX . "wt_filter_option_value_description` (option_id, value_id, language_id, name) VALUES ('" . (int)$result['option_id'] . "', '" . $this->db->escape($value_id) . "', '" . (int)$this->config->get('config_language_id') . "', '" . $this->db->escape($value) . "')");
				}

				$this->db->query("INSERT INTO `" . DB_PREFIX . "wt_filter_option_value_to_product` (product_id, option_id, value_id) SELECT oov2p.product_id, '" . (int)$result['option_id'] . "', '" . $this->db->escape($value_id) . "' FROM `" . DB_PREFIX . "wt_filter_option_value_to_product` oov2p WHERE oov2p.option_id = '" . (int)$result['option_id'] . "' AND oov2p.value_id = '" . $this->db->escape($result['value_id']) . "'");
			}

			if ($values) {
				$this->db->query("DELETE FROM `" . DB_PREFIX . "wt_filter_option_value` WHERE value_id = '" . $this->db->escape($result['value_id']) . "'");
				$this->db->query("DELETE FROM `" . DB_PREFIX . "wt_filter_option_value_description` WHERE language_id = '" . (int)$this->config->get('config_language_id') . "' AND value_id = '" . $this->db->escape($result['value_id']) . "'");
				$this->db->query("DELETE FROM `" . DB_PREFIX . "wt_filter_option_value_to_product` WHERE option_id = '" . (int)$result['option_id'] . "' AND value_id = '" . $this->db->escape($result['value_id']) . "'");
			}
		}
	}

	public function translit(string $string): string {
		$replace = [
			'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'ґ' => 'g', 'д' => 'd',
			'е' => 'e', 'є' => 'je', 'ё' => 'e', 'ж' => 'zh', 'з' => 'z', 'и' => 'i',
			'і' => 'i', 'ї' => 'ji', 'й' => 'j', 'к' => 'k', 'л' => 'l', 'м' => 'm',
			'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
			'у' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'ts', 'ч' => 'ch', 'ш' => 'sh',
			'щ' => 'sch', 'ъ' => '', 'ы' => 'y', 'ь' => '', 'э' => 'e', 'ю' => 'ju',
			'я' => 'ja', ' ' => '-', '+' => 'plus'
		];

		$string = mb_strtolower($string, 'UTF-8');
		$string = strtr($string, $replace);
		$string = preg_replace('![^a-zа-яёйъ0-9]+!isu', '-', $string);
		$string = preg_replace('!\-{2,}!si', '-', $string);

		return trim((string)$string, '-');
	}

	private function ucfirstUtf8(string $str): string {
		return oc_strtoupper(oc_substr($str, 0, 1)) . oc_substr($str, 1);
	}
}
