<?php
namespace Opencart\Admin\Controller\Extension\WtFilter\Module;

/**
 * Модуль wt_filter (OpenCart 4).
 * Пока только: статус + AJAX copyFilters (опции/фильтры/атрибуты → таблицы wt_filter_*).
 */
class WtFilter extends \Opencart\System\Engine\Controller {
	private string $route = 'extension/wt_filter/module/wt_filter';

	public function index(): void {
		$this->load->language($this->route);

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'])
		];

		$data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');
		$data['user_token'] = $this->session->data['user_token'];

		$data['module_wt_filter_status'] = $this->config->get('module_wt_filter_status');
		$data['module_wt_filter_attribute_separator'] = $this->config->get('module_wt_filter_attribute_separator');

		$data['types'] = ['checkbox', 'radio', 'select'];

		$this->load->model('setting/store');
		$data['stores'] = $this->model_setting_store->getStores();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view($this->route, $data));
	}

	public function save(): void {
		$this->load->language($this->route);

		$json = [];

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting('module_wt_filter', $this->request->post);
			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * AJAX: один шаг копирования (прогресс-бар).
	 * POST step = truncate|option|filter|attribute|finalize
	 */
	public function copyFilters(): void {
		$this->load->language($this->route);

		$json = [];

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error'] = $this->language->get('error_permission');
		}

		if ($this->request->server['REQUEST_METHOD'] == 'POST' && empty($json['error'])) {
			if (!isset($this->request->post['copy_store'])) {
				$json['error'] = $this->language->get('error_copy_store');
			}

			if (empty($this->request->post['copy_type'])) {
				$json['error'] = $this->language->get('error_copy_type');
			}

			$step = isset($this->request->post['step']) ? (string)$this->request->post['step'] : '';
			$allowed = ['truncate', 'option', 'filter', 'attribute', 'finalize'];

			if (!in_array($step, $allowed, true)) {
				$json['error'] = $this->language->get('error_copy_step');
			}

			if (empty($json['error'])) {
				try {
					$this->load->model('extension/wt_filter/catalog/wt_filter');
					$this->model_extension_wt_filter_catalog_wt_filter->copyFiltersStep($step, $this->request->post);

					$messages = [
						'truncate'  => $this->language->get('text_progress_truncate'),
						'option'    => $this->language->get('text_progress_option'),
						'filter'    => $this->language->get('text_progress_filter'),
						'attribute' => $this->language->get('text_progress_attribute'),
						'finalize'  => $this->language->get('text_progress_finalize'),
					];

					$json['success'] = true;
					$json['step'] = $step;
					$json['message'] = $messages[$step] ?? $step;

					if ($step === 'finalize') {
						$json['complete'] = true;
						$json['message'] = $this->language->get('text_complete');
					}
				} catch (\Throwable $e) {
					$json['error'] = strip_tags($e->getMessage());
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Event: admin/view/common/column_left/before
	 * В OC4 OCMOD на column_left часто не срабатывает (вложенный load->controller),
	 * поэтому пункт меню добавляем через Event.
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param string               $code
	 * @param mixed                $output
	 */
	public function eventMenu(string &$route, array &$data, string &$code = '', mixed &$output = null): void {
		if (!$this->user->hasPermission('access', 'extension/wt_filter/catalog/wt_filter')) {
			return;
		}

		if (empty($data['menus']) || !is_array($data['menus'])) {
			return;
		}

		foreach ($data['menus'] as &$menu) {
			if (($menu['id'] ?? '') !== 'menu-catalog') {
				continue;
			}

			foreach ($menu['children'] as $child) {
				if (($child['href'] ?? '') && str_contains((string)$child['href'], 'extension/wt_filter/catalog/wt_filter')) {
					return;
				}
			}

			$menu['children'][] = [
				'name'     => 'WT Filter',
				'href'     => $this->url->link('extension/wt_filter/catalog/wt_filter', 'user_token=' . $this->session->data['user_token']),
				'children' => []
			];

			break;
		}
		unset($menu);
	}

	public function install(): void {
		$this->load->model('extension/wt_filter/catalog/wt_filter');
		$this->model_extension_wt_filter_catalog_wt_filter->install();

		// Права для меню / модуля
		$this->load->model('user/user_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/wt_filter/catalog/wt_filter');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/wt_filter/catalog/wt_filter');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/wt_filter/module/wt_filter');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/wt_filter/module/wt_filter');

		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('wt_filter_menu');
		$this->model_setting_event->addEvent([
			'code'        => 'wt_filter_menu',
			'description' => 'WT Filter catalog menu item',
			'trigger'     => 'admin/view/common/column_left/before',
			'action'      => 'extension/wt_filter/module/wt_filter.eventMenu',
			'status'      => 1,
			'sort_order'  => 1
		]);

		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_wt_filter', [
			'module_wt_filter_status' => 0
		]);
	}

	public function uninstall(): void {
		$this->load->model('extension/wt_filter/catalog/wt_filter');
		$this->model_extension_wt_filter_catalog_wt_filter->uninstall();

		$this->load->model('setting/event');
		$this->model_setting_event->deleteEventByCode('wt_filter_menu');

		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_wt_filter');
	}
}
